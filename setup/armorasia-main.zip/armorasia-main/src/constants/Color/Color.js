const Color = {
  primary: 'color-primary-default',
  primaryActive: 'color-primary-active',
  disable: 'color-primary-disabled',
  second: '#FA8F88',
  bgDefault: 'background-basic-color-1',
  stroke: 'background-basic-color-3',
  bgGrey: 'background-basic-color-3',
  success: 'color-success-default',
  error: 'color-danger-default',
  warning: 'color-warning-default',
  label: 'color-basic-600',
  text: 'color-basic-800',
};

export default Color;

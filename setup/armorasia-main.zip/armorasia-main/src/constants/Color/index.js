import Color from './Color';
export default Color;

import React from 'react';
import {
  CardStyleInterpolators,
  createStackNavigator,
  TransitionPresets,
} from '@react-navigation/stack';

// Screens
import MainTabs from './BottomNavigation';
import SplashScreen from '../screens/SplashScreen';
import EventScreen from '../screens/EventScreen';

const Stack = createStackNavigator();

export default function AppNavigation(props) {
  const bottomTop = {
    ...TransitionPresets.ModalTransition,
    gestureEnabled: false,
  };
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        cardStyleInterpolator: CardStyleInterpolators.forHorizontalIOS,
      }}>
      <Stack.Screen name="SplashScreen" component={SplashScreen} />
      <Stack.Screen name="Main" component={MainTabs} />
      <Stack.Screen name="EventScreen" component={EventScreen} />
    </Stack.Navigator>
  );
}

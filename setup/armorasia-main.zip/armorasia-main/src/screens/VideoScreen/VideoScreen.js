import React from 'react';
import { useStyleSheet, StyleService } from '@ui-kitten/components';
import { SafeAreaView, Image } from 'react-native';
import { Color } from '@constants';
import { Text, Header, Button, View } from '@components';
import { useTranslation } from 'react-i18next';

export default function VideoScreen({ navigation }) {
  const styles = useStyleSheet(themedStyles);
  const { t } = useTranslation();
  return (
    <SafeAreaView style={styles.safeAreaView}>
      <Header title="Video" />
      <View style={styles.container}>
        <Image
          source={require('@images/videoHero.png')}
          resizeMode="contain"
          style={{ width: 290, height: 290 }}
        />
        <Button style={styles.button} onPress={() => {}} activeOpacity={0.7} appearance="outline">
          {t('View Safety Video')}
        </Button>
      </View>
    </SafeAreaView>
  );
}

const themedStyles = StyleService.create({
  safeAreaView: {
    backgroundColor: Color.bgDefault,
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  button: {
    maxWidth: 300,
    width: '80%',
    backgroundColor: Color.bgDefault,
  },
});

import VideoScreen from './VideoScreen';
export default VideoScreen;

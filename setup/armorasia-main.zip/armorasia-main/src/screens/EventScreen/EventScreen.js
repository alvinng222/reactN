import React from 'react';
import { useStyleSheet, StyleService } from '@ui-kitten/components';
import { SafeAreaView } from 'react-native';
import { Color } from '@constants';
import { Text, Header, View } from '@components';
import { useTranslation } from 'react-i18next';

export default function EventScreen() {
  const styles = useStyleSheet(themedStyles);
  const { t } = useTranslation();

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <Header title="EventScreen" />
      <View style={styles.container}>
        <Text>{t('EventScreen')}</Text>
      </View>
    </SafeAreaView>
  );
}

const themedStyles = StyleService.create({
  safeAreaView: {
    backgroundColor: Color.bgDefault,
    flex: 1,
  },
  container: {
    flex: 1,
  },
});

import EventScreen from './EventScreen';
export default EventScreen;

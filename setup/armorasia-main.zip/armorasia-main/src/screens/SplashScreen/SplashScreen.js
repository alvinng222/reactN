import React, { useEffect } from 'react';
import { useStyleSheet, StyleService, Layout } from '@ui-kitten/components';
import { SafeAreaView, Image } from 'react-native';
import { Color } from '@constants';
import Text from '@components/Text';

export default function SplashScreen({ navigation }) {
  const styles = useStyleSheet(themedStyles);
  useEffect(() => {
    const timeOut = setTimeout(() => {
      navigation.replace('Main');
    }, 1500);
    return () => {
      clearTimeout(timeOut);
    };
  }, []);
  return (
    <SafeAreaView style={styles.safeAreaView}>
      <Layout style={styles.container}>
        <Image
          source={require('@images/logo.png')}
          resizeMode="contain"
          style={{ width: 275, flex: 1 }}
        />
        <Text type="label">Powered by Findjobs Pte Ltd</Text>
      </Layout>
    </SafeAreaView>
  );
}

const themedStyles = StyleService.create({
  safeAreaView: {
    backgroundColor: Color.bgDefault,
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

import React from 'react';
import {
  useStyleSheet,
  StyleService,
  Layout,
  TopNavigationAction,
  Icon,
  useTheme,
} from '@ui-kitten/components';
import { Alert, SafeAreaView } from 'react-native';
import { Color } from '@constants';
import { Text, Header } from '@components';
import { useTranslation } from 'react-i18next';
export default function ArticlesScreen() {
  const styles = useStyleSheet(themedStyles);
  const theme = useTheme();
  const { t } = useTranslation();

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <Header
        title="Articles"
        accessoryRight={() => (
          <TopNavigationAction
            icon={(props) => <Icon {...props} name="search" fill={theme[Color.label]} />}
            onPress={() => Alert.alert('Search lo')}
          />
        )}
      />
      <Layout style={styles.container}>
        <Text>{t('Articles')}</Text>
      </Layout>
    </SafeAreaView>
  );
}

const themedStyles = StyleService.create({
  safeAreaView: {
    backgroundColor: Color.bgDefault,
    flex: 1,
  },
  container: {
    flex: 1,
  },
  icon: {
    color: Color.label,
  },
});

import React from 'react';
import { useStyleSheet, StyleService } from '@ui-kitten/components';
import { SafeAreaView } from 'react-native';
import { Color } from '@constants';
import { Text, Header, View } from '@components';
import { useTranslation } from 'react-i18next';

export default function ReportScreen() {
  const styles = useStyleSheet(themedStyles);
  const { t } = useTranslation();

  return (
    <SafeAreaView style={styles.safeAreaView}>
      <Header title="ReportScreen" />
      <View style={styles.container}>
        <Text>{t('ReportScreen')}</Text>
      </View>
    </SafeAreaView>
  );
}

const themedStyles = StyleService.create({
  safeAreaView: {
    backgroundColor: Color.bgDefault,
    flex: 1,
  },
  container: {
    flex: 1,
  },
});

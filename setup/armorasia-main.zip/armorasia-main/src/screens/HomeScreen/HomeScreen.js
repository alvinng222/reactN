import React, { useState } from 'react';
import { StyleSheet, SafeAreaView, ScrollView } from 'react-native';
import { useTheme } from '@ui-kitten/components';
import { ThemeContext } from '../../constants/theme/theme-context';
import Header from '../../components/Header/Header';
import { Modal, Text, Button, View } from '@components';
import { Color } from '@constants';

export default function Home({ navigation }) {
  const [value, setValue] = React.useState('');
  const [isModal, setIsModal] = useState(false);
  const themeContext = React.useContext(ThemeContext);
  const theme = useTheme();

  const toggleModal = () => {
    setIsModal((prevState) => !prevState);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme[Color.bgDefault] }}>
      <Header title={"What's New"} />
      <ScrollView style={{ flex: 1 }}>
        <Button style={{ margin: 10 }} onPress={() => themeContext.toggleTheme()}>
          Change Theme
        </Button>
        <Button style={{ margin: 10 }} onPress={() => navigation.navigate('EventScreen')}>
          Open Event Screen
        </Button>
        <Button style={{ margin: 10 }} onPress={toggleModal}>
          Open Menu
        </Button>
      </ScrollView>
      <Modal isVisible={isModal} onRequestClose={toggleModal} title="Modal">
        <View style={{ backgroundColor: '#ff0000' }}>
          <Text>agagag</Text>
          <Text>agagag</Text>
          <Text>agagag</Text>
          <Text>agagag</Text>
          <Text>agagag</Text>
          <Text>agagag</Text>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  text: {
    margin: 2,
  },
});

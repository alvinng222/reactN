import { useTheme } from '@ui-kitten/components';
import * as React from 'react';
import { Image, StyleSheet } from 'react-native';
import { Color } from '../constants';
import { View } from '../components';

export default function TabBarIcon(props) {
  const theme = useTheme();
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center' }}>
      <Image
        style={[
          styles.image,
          {
            tintColor: props.focused === true ? theme[Color.primary] : theme[Color.label],
          },
          props.style,
        ]}
        source={props.focused ? props.selected : props.noSelected}
        resizeMode={'contain'}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  image: {
    width: 25,
    height: 25,
    resizeMode: 'contain',
  },
});

// <Ionicons
//   name={props.name}
//   size={30}
//   style={{ marginBottom: -3 }}
//   color={props.focused ? Colors.tabIconSelected : Colors.tabIconDefault}
// />

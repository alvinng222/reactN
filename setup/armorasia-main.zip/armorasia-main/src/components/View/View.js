/***
 * Custome View base on Ui Kitten
 * @property {string} level
 * - Can be [1,2,3,4]
 *
 * Usage
 * import { View } from '@components' ;
 *
 */

import React from 'react';
import { Layout } from '@ui-kitten/components';

export default function View(props) {
  return <Layout {...props} />;
}

/**
 * @param props
 */

import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Button as ThemeButton } from '@ui-kitten/components';

export default function Button({ style, ...props }) {
  return (
    <ThemeButton style={[{ borderRadius: 50 }, style]} {...props}>
      {props.children}
      {props.title}
    </ThemeButton>
  );
}

import React from 'react';
import { Text as ThemeText, useStyleSheet, StyleService } from '@ui-kitten/components';
import { Color } from '@constants';

export default function Text({ type = 'paragraph', style, color, ...props }) {
  const styles = useStyleSheet(themedStyles);
  return <ThemeText style={[styles[type], color && { color: color }, style]} {...props} />;
}

const themedStyles = StyleService.create({
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  paragraph: {
    fontSize: 14,
  },
  label: {
    fontSize: 12,
    color: Color.label,
  },
});

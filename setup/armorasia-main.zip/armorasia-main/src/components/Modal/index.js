// new modal using react-native modal
import Modal from './Modal';
export default Modal;

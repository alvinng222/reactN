/**
 * @property {string} type - Modal Type
 * to determine which type of modal to render ['fullScreen' , 'default' , 'bottom']
 *
 */

// Define different type of Modal
// All modal containe close button , and confirm button (required props.textButton to render)
// DefaultModal = height 450,
// ResponsiveModal = minheight 270, adjustable height (define by props.viewHeight)

import React from 'react';
import { SafeAreaView, Dimensions } from 'react-native';
import { useStyleSheet, StyleService } from '@ui-kitten/components';
import BaseModal from 'react-native-modal';
import { Color } from '@constants';
import Header from '@components/Header';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

const Modal = (props) => {
  if (props.type === 'fullScreen') {
    return <FullPageModal {...props} />;
  } else if (props.type === 'bottom') {
    return <BottomModal {...props} />;
  }
  return <DefaultModal {...props} />;
};

// base ui component
const CustomModal = ({
  onRequestClose,
  children,
  modalStyle,
  viewStyle,
  onBackdropPress,
  noHeader,
  cleanModal, // whether show preset Safeareaview or not
  ...props
}) => {
  return (
    <BaseModal
      backdropTransitionOutTiming={0}
      hideModalContentWhileAnimating
      onBackdropPress={onBackdropPress || onRequestClose}
      onBackButtonPress={onRequestClose}
      propagateSwipe
      {...props}
      style={{ margin: 0, ...modalStyle }}>
      {!cleanModal ? (
        <SafeAreaView style={viewStyle}>
          {!noHeader && <Header isClose onBack={onRequestClose} {...props} />}
          {children}
        </SafeAreaView>
      ) : (
        <>{children}</>
      )}
    </BaseModal>
  );
};

const DefaultModal = ({ customStyle, modalHeight, ...props }) => {
  const styles = useStyleSheet(themedStyles);
  return (
    <CustomModal
      statusBarTranslucent
      {...props}
      modalStyle={{ alignItems: 'center' }}
      viewStyle={[
        styles.modal,
        modalHeight && { height: modalHeight, maxHeight: modalHeight },
        customStyle,
      ]}
    />
  );
};

const BottomModal = ({ customStyle, ...props }) => {
  const styles = useStyleSheet(themedStyles);
  return (
    <CustomModal
      statusBarTranslucent
      {...props}
      modalStyle={{ justifyContent: 'flex-end' }}
      viewStyle={[styles.bottomModal, customStyle]}
    />
  );
};
const FullPageModal = ({ customStyle, ...props }) => {
  const styles = useStyleSheet(themedStyles);
  return (
    <CustomModal
      {...props}
      modalStyle={{ justifyContent: 'flex-end' }}
      viewStyle={[styles.fullPageModal, customStyle]}
    />
  );
};

export default Modal;

const themedStyles = StyleService.create({
  modal: {
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: Color.bgDefault,
    maxHeight: '70%',
    minHeight: height > 800 ? 500 : '50%',
    width: width > 450 ? 450 : '80%',
  },
  fullPageModal: {
    flex: 1,
    backgroundColor: Color.bgDefault,
  },
  bottomModal: {
    alignSelf: 'flex-end',
    width: '100%',
    backgroundColor: Color.bgDefault,
    maxHeight: '95%',
    minHeight: 120,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    overflow: 'hidden',
  },
});

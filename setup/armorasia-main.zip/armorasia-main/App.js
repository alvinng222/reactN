import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AppNavigation from './src/navigation/AppNavigation';
import i18n from './src/localization';
import { I18nextProvider } from 'react-i18next';
import * as eva from '@eva-design/eva';
import { ApplicationProvider, IconRegistry } from '@ui-kitten/components';
import { default as myTheme } from './src/constants/theme'; // <-- Import app theme
import { default as mapping } from './src/constants/mapping.json'; // <-- Import app mapping
import { EvaIconsPack } from '@ui-kitten/eva-icons';
import { ThemeContext } from './src/constants/theme/theme-context';
import { StatusBar, Platform } from 'react-native';

export default function App() {
  const [theme, setTheme] = React.useState('light');
  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
  };
  return (
    <I18nextProvider i18n={i18n}>
      <IconRegistry icons={EvaIconsPack} />
      <ThemeContext.Provider value={{ theme, toggleTheme }}>
        <ApplicationProvider
          {...eva}
          theme={{ ...eva[theme], ...myTheme[theme] }}
          customMapping={mapping}>
          <NavigationContainer>
            {/* if ios, change status bar content color base on theme , android always use light content */}
            <StatusBar
              barStyle={
                Platform.OS === 'ios'
                  ? theme === 'dark'
                    ? 'light-content'
                    : 'dark-content'
                  : 'light-content'
              }
            />
            <AppNavigation />
          </NavigationContainer>
        </ApplicationProvider>
      </ThemeContext.Provider>
    </I18nextProvider>
  );
}
